package com.example.mysemester.Features.Create;

public interface StudentCreateListener {
    void onStudentCreated(Student student);
}