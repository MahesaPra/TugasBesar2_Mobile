package com.example.mysemester.Features.Update;

import com.example.mysemester.Features.Create.Student;

public interface StudentUpdateListener {
    void onStudentInfoUpdated(Student student, int position);
}
