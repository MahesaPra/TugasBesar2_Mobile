package com.example.mysemester.Features.Create;

public interface SubjectCreateListener {
    void onSubjectCreated(Subject subject);
}
