package com.example.mysemester.Features.Update;

import com.example.mysemester.Features.Create.Subject;

public interface SubjectUpdateListener {
    void onSubjectInfoUpdated(Subject subject, int position);
}
